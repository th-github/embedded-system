/* signal_5 */
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>

void signup_handler()
{
	int pid = getpid();
	printf("\nIn signup_handler. pid: %d\n", pid);
}

void sigint_handler()
{
	int pid = getpid();
	printf("\nIn sigint_handler. pid: %d\n", pid);
}

void sigquit_handler()
{
	int pid = getpid();
	printf("\nIn sigquit_handler. pid: %d\n", pid);
    sleep(3);
}

void sigchld_handler()
{
   int pid = getpid();
   printf("\nIn sigchld_handler. pid: %d\n", pid);
}

void main()
{
	int pid0;
	int pid = getpid();
	
	printf("\nparent: register signup_handler. pid: %d\n", pid);
	signal(SIGHUP, signup_handler);
	printf("parent: register sigint_handler. pid: %d\n", pid);
	signal(SIGINT, sigint_handler);
	printf("parent: register sigquit_handler. pid: %d\n", pid);
	signal(SIGQUIT, sigquit_handler);
    printf("parent: register sigchld_handler. pid: %d\n", pid);
	signal(SIGCHLD, sigchld_handler);
   
	if ((pid0 = fork()) < 0) {
		perror("fork");
		exit(1);
	}
	if (pid0 == 0)
	{
		pid = getpid();
		printf("\nchild process invoked. pid: %d\n", pid);

		printf("\nchild: register signup_handler. pid: %d\n", pid);
		signal(SIGHUP, signup_handler);
		printf("\nchild: register sigint_handler. pid: %d\n", pid);
		signal(SIGINT, sigint_handler);

		printf("\nchild: register sigquit_handler. pid: %d\n", pid);
		printf("\nchild: about to send SIGQUIT. pid: %d\n", pid);
		signal(SIGQUIT, sigquit_handler);
		
        printf("\nchild: about to send SIGINT... pid: %d", pid);   
        kill(pid, SIGINT);
        
	    printf("child: after SIGINT was sent, let child process sleep\n");
        while(1);
        	
	}
	else 
	{
		pid = getpid();
    	//sleep(1);     
        signal(SIGINT, SIG_IGN);   // ignore any further SIGINT 
        printf("\nparent: sent SIGINT. parent pid: %d\n", pid);
		sleep(2);
	}

	printf("\n");
}
