/* signal_2 */
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>

void signup_handler()
{
	int pid = getpid();
	signal(SIGHUP, SIG_IGN);   // ignore any further SIGHUP
	printf("\nIn signup_handler. pid: %d\n", pid);
}

void sigint_handler()
{
	int pid = getpid();
	signal(SIGINT, SIG_IGN);   // ignore any further SIGINT 
	printf("\nIn sigint_handler. pid: %d\n", pid);	
}

void sigquit_handler()
{
	int pid = getpid();
	printf("\nIn sigquit_handler. pid: %d\n", pid);	
}

void main()
{
	int pid0;
	int pid = getpid();
	
	printf("\nparent: register signup_handler. pid: %d\n", pid);
	signal(SIGHUP, signup_handler);
	printf("\nparent: register sigint_handler. pid: %d\n", pid);
	signal(SIGINT, sigint_handler);
	printf("\nparent: register sigquit_handler. pid: %d\n", pid);
	signal(SIGQUIT, sigquit_handler);
	
	if ((pid0 = fork()) < 0) {
		perror("fork");
		exit(1);
	}
	if (pid0 == 0)
	{
		pid = getpid();
		printf("\nchild process invoked. pid: %d\n", pid);
		
		printf("\nchild: register signup_handler. pid: %d\n", pid);
		signal(SIGHUP, signup_handler);
		printf("\nchild: register sigint_handler. pid: %d\n", pid);
		signal(SIGINT, sigint_handler);
		printf("\nchild: register sigquit_handler. pid: %d\n", pid);
		signal(SIGQUIT, sigquit_handler);
		
		while(1);
	}
	else 
	{
		pid = getpid();
      
		kill(pid, SIGHUP);
      		// if this SIGHUP signal is caught before the following printf,
      		// then the signal was taken immediately upon entrance
		printf("\nparent: 1st sent of SIGHUP. parent pid: %d\n", pid);
		kill(pid, SIGHUP);
		printf("\nparent: 2nd sent of SIGHUP. parent pid: %d\n", pid);
      		// the 2nd send should have been ignored because the signal 
      		// sends itself signal(SIGHUP, SIG_IGN);

		kill(pid, SIGINT);
      		// if this SIGINT signal is caught before the following printf,
      		// then the signal was taken immediately upon entrance
		kill(pid, SIGINT);
      		// the 2nd send should have been ignored because the signal 
      		// sends itself signal(SIGINT, SIG_IGN);
		printf("\nparent: send SIGINT twice. parent pid: %d\n", pid);

		printf("\nparent: about to send SIGQUIT... parent pid: %d\n", pid);
		kill(pid, SIGQUIT);
		kill(pid, SIGQUIT);
		printf("\nparent: 2nd send SIGQUIT parent pid: %d", pid);
		printf("\nThis signal handler does not ignore further SIGQUIT\n");
	
		sleep(3);
	}

	printf("\n");
}
