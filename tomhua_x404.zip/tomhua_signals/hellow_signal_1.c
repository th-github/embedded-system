/* signal_1 */
#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <unistd.h>

void signup_handler()
{
	int pid = getpid();
	signal(SIGHUP, SIG_IGN);
	printf("\nFrom signup_handler. pid: %d\n", pid);
}

void sigint_handler()
{
	int pid = getpid();
	signal(SIGINT, SIG_IGN);
	printf("\nFrom sigint_handler. pid: %d\n", pid);	
}

void sigquit_handler()
{
	int pid = getpid();
	signal(SIGQUIT, SIG_IGN);
	printf("\nFrom sigquit_handler. pid: %d\n", pid);	
}

void main()
{
	int pid0;
	int pid = getpid();
	
	printf("\nparent: setup signup_handler. pid: %d\n", pid);
	signal(SIGHUP, signup_handler);
	printf("\nparent: setup sigint_handler. pid: %d\n", pid);
	signal(SIGINT, sigint_handler);
	printf("\nparent: setup sigquit_handler. pid: %d\n", pid);
	signal(SIGQUIT, sigquit_handler);
	
	if ((pid0 = fork()) < 0) {
		perror("fork");
		exit(1);
	}
	if (pid0 == 0)
	{
		pid = getpid();
		printf("\nchild process invoked. pid: %d\n", pid);
		
		printf("\nchild: setup signup_handler. pid: %d\n", pid);
		signal(SIGHUP, signup_handler);
		printf("\nchild: setup sigint_handler. pid: %d\n", pid);
		signal(SIGINT, sigint_handler);
		printf("\nchild: setup sigquit_handler. pid: %d\n", pid);
		signal(SIGQUIT, sigquit_handler);
		
		while(1);
	}
	else 
	{
		pid = getpid();
		
		printf("\nparent: sending SIGHUP. parent pid: %d\n", pid);
		kill(pid, SIGHUP);
		printf("\nparent: sending SIGINT. parent pid: %d\n", pid);
		kill(pid, SIGINT);
		printf("\nparent: sending SIGQUIT. parent pid: %d\n", pid);
		kill(pid, SIGQUIT);
		
		sleep(3);
	}
}
