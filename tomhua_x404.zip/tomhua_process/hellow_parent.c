
#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/sched/signal.h>
#include <linux/types.h>
#include <linux/in.h>
#include <linux/string.h>
#include <linux/errqueue.h>



int sysint_init(void)
{
    struct task_struct* this_task;

    printk("\n\n Hello class, module loaded.\n\n");
    
    this_task = get_current();
      
    printk(KERN_ALERT "\n\n Start process: %s[%d] \n\n", 
           this_task->comm, this_task->pid); 
    
    for_each_process(this_task) {
        printk(KERN_ALERT "%15s[%d] -- child of -- %15s[%d]",
            this_task->comm, this_task->pid, \
            this_task->real_parent->comm, this_task->real_parent->pid); 
    }
    return 0;
}

void sysint_exit(void)
{
    printk(KERN_ALERT "\n\n End process. \n\n"); 
}

module_init(sysint_init);
module_exit(sysint_exit);

MODULE_LICENSE ("GPL");
MODULE_AUTHOR ("TomH");
MODULE_VERSION ("1:0.0");
MODULE_DESCRIPTION ("SHOW PROCESS INFORMATION");


